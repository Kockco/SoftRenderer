# SoftRenderer

This project is created for education purpose. 
There are many branches for each step.
Please check code in branch.

[Prerequisite]
- Visual Studio 2017 Community Edition
- CMake recent release ( https://cmake.org/download/ )

This project is designed for multi-platform support but currently implemented only for windows. 

