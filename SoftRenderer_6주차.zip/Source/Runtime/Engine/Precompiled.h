#pragma once

#include <stdio.h>
#include <math.h>
#include <cassert>
#include <memory.h>

#include "MathHeaders.h"
