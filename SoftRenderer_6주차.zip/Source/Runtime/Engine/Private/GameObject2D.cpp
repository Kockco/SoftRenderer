
#include "Precompiled.h"
#include "GameObject2D.h"

Transform2D & GameObject2D::GetTransform()
{
	return Transform;
}
