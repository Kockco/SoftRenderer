#include "ScreenPoint.h"

ScreenPoint ScreenPoint::operator-(const ScreenPoint & InPoint) const
{
	return ScreenPoint();
}
