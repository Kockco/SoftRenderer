#pragma once

typedef unsigned char BYTE;
typedef unsigned int UINT;
typedef unsigned long ULONG;
#define FORCEINLINE __forceinline

