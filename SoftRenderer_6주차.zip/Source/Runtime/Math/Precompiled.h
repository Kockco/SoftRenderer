#pragma once

#include <math.h>
#include <stdio.h>
#include <cassert>
#include <memory.h>

