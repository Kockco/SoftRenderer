#include "Precompiled.h"
#include "Color32.h"

const Color32 Color32::Error(255, 0, 255, 255);
