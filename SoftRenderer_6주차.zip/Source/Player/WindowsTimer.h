#pragma once

class WindowsTimer 
{
public:
	static double Init();
	static __int64 CheckMilliSeconds();
};
